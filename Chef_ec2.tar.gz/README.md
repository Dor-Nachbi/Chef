# Chef_ec2
This repo is the base for the ec2 machines that will actually perform the installation of the prerequisites and run the server in order for my web-app to be live
